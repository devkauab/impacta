fun main(){
    for (i in 39..201){
    if (i % 2 == 0){
    println(i*i)
    }
    }
}