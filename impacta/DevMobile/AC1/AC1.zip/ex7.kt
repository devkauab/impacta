fun main(){
    var x: Int = 454
    for (num in 1 .. x){
    if (num % 5 == 0){
    println(num)
    }
    }
}